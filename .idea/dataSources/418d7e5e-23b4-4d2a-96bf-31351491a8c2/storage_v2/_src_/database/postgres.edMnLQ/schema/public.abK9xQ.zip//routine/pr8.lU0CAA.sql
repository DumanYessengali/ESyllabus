create procedure pr8()
    language plpgsql
as
$$
declare
   rec record;
begin
    for rec in select t_id, first_name, last_name, where_from, EXPO_id, email, age
        from tourist
            where  first_name like 'B%'
    loop
      raise notice '%  ', rec;
    end loop;
   commit;
end;
$$;

alter procedure pr8() owner to postgres;

