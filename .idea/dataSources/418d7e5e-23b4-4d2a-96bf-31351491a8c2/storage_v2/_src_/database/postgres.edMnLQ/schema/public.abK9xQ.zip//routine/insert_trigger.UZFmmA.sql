create function insert_trigger() returns trigger
    language plpgsql
as
$$
begin
	insert into dep_audit(department_name, manager_id, locations_id, insertion_time)
	values (new.department_name, new.manager_id, new.locations_id, now());
	return new;
end
$$;

alter function insert_trigger() owner to postgres;

