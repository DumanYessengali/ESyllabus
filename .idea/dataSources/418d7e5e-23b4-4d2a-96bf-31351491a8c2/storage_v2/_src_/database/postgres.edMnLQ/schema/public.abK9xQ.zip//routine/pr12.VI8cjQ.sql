create procedure pr12(fromwhereid integer, towhomid integer, sum integer)
    language plpgsql
as
$$
begin
    update ticket
   set cost = cost -sum
   where ticket_id = FromWhereId;

   update ticket
   set cost = cost + sum
   where ticket_id = ToWhomId;
   commit;
end
$$;

alter procedure pr12(integer, integer, integer) owner to postgres;

