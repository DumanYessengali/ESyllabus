create function pr3()
    returns TABLE(maxcost integer, mincost integer)
    language plpgsql
as
$$
declare
    MaxCostR int;
    MinCostR int;
begin
    for  MaxCostR,MinCostR in select  max(Cost),min(Cost)
        from ticket
        loop
            MaxCost:=MaxCostR;
            MinCost:= MinCostR;
      return next;
      end loop;
end
$$;

alter function pr3() owner to postgres;

