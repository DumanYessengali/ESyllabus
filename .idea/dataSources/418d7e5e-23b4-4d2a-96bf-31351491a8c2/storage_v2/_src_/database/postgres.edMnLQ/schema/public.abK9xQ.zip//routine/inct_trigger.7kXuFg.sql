create function inct_trigger() returns trigger
    language plpgsql
as
$$
begin
	insert into e_audit(first_name, last_name, salary)
	values (new.first_name, new.last_name, new.salary);
	return new;
end
$$;

alter function inct_trigger() owner to postgres;

