create procedure task7_4select()
    language plpgsql
as
$$
declare
	rec record;
begin
    for rec in select employee_id,first_name,last_name,salary
    from employee
    where first_name = 'Aube' or employee_id = 35
    loop
		raise notice '% % %  Salary is - %', rec.employee_id, rec.first_name,rec.last_name, rec.salary;
	 end loop;
	commit;
end
$$;

alter procedure task7_4select() owner to postgres;

