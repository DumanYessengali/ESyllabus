create view tel(tour_name, email, tel) as
SELECT officel_tour_operators.tour_name,
       officel_tour_operators.email,
       officel_tour_operators.tel
FROM officel_tour_operators
WHERE officel_tour_operators.tel::text ~~ '_3____________'::text;

alter table tel
    owner to postgres;

