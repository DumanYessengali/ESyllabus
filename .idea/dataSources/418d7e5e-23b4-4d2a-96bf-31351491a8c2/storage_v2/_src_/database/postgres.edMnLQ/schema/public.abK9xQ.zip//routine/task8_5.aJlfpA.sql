create procedure task8_5()
    language plpgsql
as
$$
declare
        rec record;
        cur cursor for select first_name,last_name,salary,department_id
            from employee
                where department_id >150;
    begin
        open cur;
        loop
            begin
                fetch cur into rec;
                exit when not found;
                update employee
                set salary=salary*1.1
                where current of cur;
            end;
        end loop;
    end
$$;

alter procedure task8_5() owner to postgres;

