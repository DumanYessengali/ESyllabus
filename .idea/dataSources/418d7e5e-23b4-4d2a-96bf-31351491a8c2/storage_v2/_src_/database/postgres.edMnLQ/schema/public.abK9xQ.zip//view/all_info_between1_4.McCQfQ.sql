create view all_info_between1_4(address, name, hire_date) as
SELECT expo_2017.address,
       expo_2017.name,
       expo_2017.hire_date
FROM expo_2017
WHERE expo_2017.expo_id >= 1
  AND expo_2017.expo_id <= 4;

alter table all_info_between1_4
    owner to postgres;

