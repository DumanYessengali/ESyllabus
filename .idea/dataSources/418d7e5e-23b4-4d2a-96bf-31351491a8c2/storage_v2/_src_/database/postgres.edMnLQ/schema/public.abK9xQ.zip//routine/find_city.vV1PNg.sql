create function find_city(findcity character varying)
    returns TABLE(returncity character varying)
    language plpgsql
as
$$
declare
    cityL locations.city%type;
begin
    return query
    select city
        from locations
        where city = FindCity;
            if not found then
                raise notice 'City  not found';
            end if;

end
$$;

alter function find_city(varchar) owner to postgres;

