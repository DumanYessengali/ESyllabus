create function turist_trigg() returns trigger
    language plpgsql
as
$$
begin
   insert into tur_audit( first_name, last_name, where_from,changed_time)
   values (new.first_name, new.last_name,new.where_from, now());
   return new;
end
$$;

alter function turist_trigg() owner to postgres;

