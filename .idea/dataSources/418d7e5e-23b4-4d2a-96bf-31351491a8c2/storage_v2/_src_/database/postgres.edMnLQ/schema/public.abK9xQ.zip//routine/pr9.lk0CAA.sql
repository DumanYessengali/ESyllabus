create procedure pr9()
    language plpgsql
as
$$
declare
   rec record;
begin
    for rec in select t_id, first_name, last_name, where_from, age
    from tourist
    where age = 25 or first_name = 'Kalem'
    loop
      raise notice 'Id:% | % | %  | % | %', rec.t_id, rec.first_name,rec.last_name, rec.where_from,rec.age;
    end loop;
   commit;
end
$$;

alter procedure pr9() owner to postgres;

