create function task8_7() returns record
    language plpgsql
as
$$
declare
        newText text default '';
        rec record;
        cur cursor
            for select  d.department_name, d.manager_id, d.locations_id, e.first_name,e.last_name,e.department_id
                    from department d
                    inner join employee e on d.department_id = e.department_id
                    where department_name like 'S%';

    begin
        open cur;
        fetch cur into rec;
        return rec;
        close cur;

    end
$$;

alter function task8_7() owner to postgres;

