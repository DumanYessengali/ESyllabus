create procedure pr11()
    language plpgsql
as
$$
declare
   rec record;
begin
    for rec in select ticket_id, descr, sale_channels, cost, t_id, expo_id, date
    from ticket
    loop
      raise notice 'Id:% | % | %  | % | %', rec.ticket_id, rec.descr,rec.sale_channels, rec.cost,rec.date;
    end loop;
   commit;
end
$$;

alter procedure pr11() owner to postgres;

