create function task8_6(refcursor, refcursor, name character varying) returns SETOF refcursor
    language plpgsql
as
$$
BEGIN
    OPEN $1 FOR SELECT * FROM department;
    RETURN NEXT $1;
    OPEN $2 FOR SELECT * FROM department
    WHERE department_name=name;
    RETURN NEXT $2;
END;
$$;

alter function task8_6(refcursor, refcursor, varchar) owner to postgres;

