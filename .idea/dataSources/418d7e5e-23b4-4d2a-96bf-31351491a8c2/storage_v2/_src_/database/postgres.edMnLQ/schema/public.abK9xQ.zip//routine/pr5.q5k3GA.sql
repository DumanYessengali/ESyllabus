create function pr5(refcursor) returns text
    language plpgsql
as
$$
begin
        OPEN $1  for select *
                    from EXPO_2017 e
                    inner join city c on e.c_id = c.c_id
                    where Name_city like 'Adsds%';
        RETURN $1;
         exception
            when no_data_found then
                raise exception 'City not found';
            when sqlstate 'P0002'then
                raise exception 'City not found';
            when sqlstate 'P0003' then
                raise exception 'City not unique';
    end
$$;

alter function pr5(refcursor) owner to postgres;

