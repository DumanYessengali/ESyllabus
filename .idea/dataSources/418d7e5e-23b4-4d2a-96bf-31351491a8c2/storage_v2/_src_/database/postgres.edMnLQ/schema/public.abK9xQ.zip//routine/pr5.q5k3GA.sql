create function pr5(refcursor) returns SETOF refcursor
    language plpgsql
as
$$
begin
        OPEN $1  for select *
                    from EXPO_2017 e
                    inner join city c on e.c_id = c.c_id
                    where Name_city like 'A%';
        RETURN NEXT $1;
    end
$$;

alter function pr5(refcursor) owner to postgres;

