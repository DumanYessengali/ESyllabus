create view full_name1(first_name, last_name) as
SELECT employee.first_name,
       employee.last_name
FROM employee;

alter table full_name1
    owner to postgres;

