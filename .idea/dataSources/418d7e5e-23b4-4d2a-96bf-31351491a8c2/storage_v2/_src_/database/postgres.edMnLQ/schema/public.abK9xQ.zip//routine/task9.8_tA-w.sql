create function task9(startp integer, endp integer) returns integer
    language plpgsql
as
$$
begin
    return floor(random()* (endP-startP + 1) + startP);
end
$$;

alter function task9(integer, integer) owner to postgres;

