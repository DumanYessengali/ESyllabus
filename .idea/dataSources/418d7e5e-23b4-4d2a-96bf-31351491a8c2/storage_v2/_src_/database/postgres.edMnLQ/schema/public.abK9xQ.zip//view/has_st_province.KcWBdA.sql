create view has_st_province(has_st_province) as
SELECT concat(locations.city, ' ', locations.state_province) AS has_st_province
FROM locations
WHERE locations.state_province IS NOT NULL;

alter table has_st_province
    owner to postgres;

