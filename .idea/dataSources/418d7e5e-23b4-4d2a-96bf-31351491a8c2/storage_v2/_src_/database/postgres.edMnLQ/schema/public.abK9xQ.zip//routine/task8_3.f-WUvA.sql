create function task8_3(refcursor) returns SETOF refcursor
    language plpgsql
as
$$
begin
        open $1 for select * from product;
        return next $1;
    end
$$;

alter function task8_3(refcursor) owner to postgres;

