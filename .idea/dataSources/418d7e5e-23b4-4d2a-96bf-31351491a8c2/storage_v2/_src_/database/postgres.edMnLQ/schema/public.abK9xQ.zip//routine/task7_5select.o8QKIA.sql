create procedure task7_5select()
    language plpgsql
as
$$
declare
	rec record;
begin
    for rec in select employee_id,phone_number,email,salary
    from employee
    where phone_number = '449-541-2166' or email = 'rtestin28@ebay.co.uk'
    loop
		raise notice 'Id:% | % | %  Salary is - %', rec.employee_id, rec.phone_number,rec.email, rec.salary;
	 end loop;
	commit;
end
$$;

alter procedure task7_5select() owner to postgres;

