create function empl_trigg() returns trigger
    language plpgsql
as
$$
begin
	insert into emp_audit( first_name, last_name, changed_time)
	values (new.first_name, new.last_name, now());
	return new;
end
$$;

alter function empl_trigg() owner to postgres;

