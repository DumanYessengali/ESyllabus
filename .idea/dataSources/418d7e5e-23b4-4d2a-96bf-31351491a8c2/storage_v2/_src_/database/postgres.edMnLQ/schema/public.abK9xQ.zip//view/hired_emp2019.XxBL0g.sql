create view hired_emp2019(first_name, last_name, gender, hire_date) as
SELECT employee.first_name,
       employee.last_name,
       employee.gender,
       employee.hire_date
FROM employee
WHERE employee.hire_date >= '2019-01-01'::date
  AND employee.hire_date <= '2019-12-31'::date;

alter table hired_emp2019
    owner to postgres;

