create procedure pr7()
    language plpgsql
as
$$
declare
        rec record;
        cur cursor for select descr, Sale_channels, Cost, date
            from ticket
                where Cost between 70000 and 80000;
    begin
        open cur;
        loop
            begin
                fetch cur into rec;
                exit when not found;
                update ticket
                set Cost=Cost*1.1
                where current of cur;
            end;
        end loop;
    end
$$;

alter procedure pr7() owner to postgres;

