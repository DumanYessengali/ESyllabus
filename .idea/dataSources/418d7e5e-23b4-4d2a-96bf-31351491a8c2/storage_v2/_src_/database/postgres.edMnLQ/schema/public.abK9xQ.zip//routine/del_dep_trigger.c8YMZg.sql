create function del_dep_trigger() returns trigger
    language plpgsql
as
$$
begin
	insert into del_dep_audit(department_name, manager_id, locations_id, deletion_time)
	values (new.department_name, new.manager_id, new.locations_id, now());
	return new;
end
$$;

alter function del_dep_trigger() owner to postgres;

