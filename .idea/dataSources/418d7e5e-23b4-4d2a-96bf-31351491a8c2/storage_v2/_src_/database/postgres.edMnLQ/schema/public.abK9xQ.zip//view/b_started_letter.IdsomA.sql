create view b_started_letter(b_started_letter) as
SELECT employee.first_name AS b_started_letter
FROM employee
WHERE employee.first_name::text ~~ 'B%'::text;

alter table b_started_letter
    owner to postgres;

