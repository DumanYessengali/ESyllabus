create function task7_1() returns character varying
    language plpgsql
as
$$
declare
    rec record;
    InsetHireDate date ='2017-02-28';

begin
    select  hire_date
    into strict rec
    from employee
    where hire_date=InsetHireDate;
    exception
        when sqlstate 'P0002' then
			 return '% not found';
		when sqlstate 'P0003' then
			return '% found';

end
$$;

alter function task7_1() owner to postgres;

