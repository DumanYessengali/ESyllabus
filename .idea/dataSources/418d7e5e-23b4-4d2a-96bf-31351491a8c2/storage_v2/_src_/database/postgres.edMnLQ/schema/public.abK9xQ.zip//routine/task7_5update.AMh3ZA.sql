create procedure task7_5update(fromwhere character varying, towhom character varying, sum integer)
    language plpgsql
as
$$
begin
    update employee
	set salary = salary -sum
	where email = FromWhere;

	update employee
	set salary = salary + sum
	where phone_number=ToWhom;
	commit;
end
$$;

alter procedure task7_5update(varchar, varchar, integer) owner to postgres;

