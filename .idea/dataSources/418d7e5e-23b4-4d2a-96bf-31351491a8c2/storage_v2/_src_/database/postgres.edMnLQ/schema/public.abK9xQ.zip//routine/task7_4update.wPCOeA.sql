create procedure task7_4update(fromwhereid integer, towhom character varying, sum integer)
    language plpgsql
as
$$
begin
    update employee
	set salary = salary -sum
	where employee_id = FromWhereId;

	update employee
	set salary = salary + sum
	where concat(first_name,' ',last_name)=ToWhom;
	commit;
end
$$;

alter procedure task7_4update(integer, varchar, integer) owner to postgres;

