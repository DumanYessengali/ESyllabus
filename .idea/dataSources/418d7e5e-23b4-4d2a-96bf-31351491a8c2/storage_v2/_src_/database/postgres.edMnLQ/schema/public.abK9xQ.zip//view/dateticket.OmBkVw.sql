create view dateticket(ticket_id, sale_channels, date) as
SELECT ticket.ticket_id,
       ticket.sale_channels,
       ticket.date
FROM ticket
WHERE ticket.date >= '2021-05-12'::date
  AND ticket.date <= '2021-08-15'::date;

alter table dateticket
    owner to postgres;

