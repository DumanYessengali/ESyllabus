create function tourist_trigg() returns trigger
    language plpgsql
as
$$
begin
   insert into tour_audit( first_name, last_name, where_from,changed_time)
   values (new.first_name, new.last_name,new.where_from, now());
   return new;
end
$$;

alter function tourist_trigg() owner to postgres;

