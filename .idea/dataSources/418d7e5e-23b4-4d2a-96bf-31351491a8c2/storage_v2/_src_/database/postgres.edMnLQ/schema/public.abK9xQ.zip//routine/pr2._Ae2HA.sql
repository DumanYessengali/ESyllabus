create function pr2(findvideo character varying) returns text
    language plpgsql
as
$$
declare
    rec record;
begin
    select video
        from press_center into strict rec
        where video = FindVideo;
            return rec.video;
            exception
            when no_data_found then
                raise exception 'Video not found';
            when sqlstate 'P0002'then
                raise exception 'Video not found';
            when sqlstate 'P0003' then
                raise exception 'Video not unique';
end
$$;

alter function pr2(varchar) owner to postgres;

