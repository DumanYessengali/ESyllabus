create function pr2(findvideo character varying)
    returns TABLE(returncity character varying)
    language plpgsql
as
$$
declare
begin
    return query
    select video
        from press_center
        where video = FindVideo;
           exception
        when sqlstate 'P0002' then
          raise exception 'not found';
      when sqlstate 'P0003' then
         raise exception 'found';

end
$$;

alter function pr2(varchar) owner to postgres;

