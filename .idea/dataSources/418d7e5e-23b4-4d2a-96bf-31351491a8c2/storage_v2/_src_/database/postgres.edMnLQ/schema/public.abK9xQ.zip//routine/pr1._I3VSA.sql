create function pr1(hiredate integer) returns character varying
    language plpgsql
as
$$
declare
    NameE varchar;
    addressE expo_2017.address%type;
begin
     select expo_id
        from expo_2017  into strict NameE,addressE
            where hire_date =hireDate;
                return  NameE||' '||addressE;
        exception
        when no_data_found then
            raise exception 'Not found';
        when sqlstate 'P0002'then
            raise exception 'Not found';
        when sqlstate 'P0003' then
            raise exception 'Not unique';

end
$$;

alter function pr1(integer) owner to postgres;

