create procedure task7_5undoupdate(fromwhere character varying, towhom character varying, sum integer)
    language plpgsql
as
$$
begin
    update employee
   set salary = salary - sum
   where email = FromWhere;

   update employee
   set salary = salary + sum
   where phone_number=ToWhom;
   ROLLBACK;
end
$$;

alter procedure task7_5undoupdate(varchar, varchar, integer) owner to postgres;

