create function task8()
    returns TABLE(returndep character varying, maxsalary integer, minsalary integer)
    language plpgsql
as
$$
declare
    deppartmenName department.department_name%type;
    MaxSalaryR int;
    MinSalaryR int;
begin
    for deppartmenName, MaxSalaryR,MinSalaryR in select  d.department_name ,max(salary) ,min(salary)
        from employee
            inner join department d on employee.department_id = d.department_id
            group by d.department_name
        loop
            ReturnDep:=deppartmenName;
            MaxSalary:=MaxSalaryR;
            MinSalary:=MinSalaryR;
		return next;
		end loop;
end
$$;

alter function task8() owner to postgres;

