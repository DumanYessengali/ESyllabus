create function pr1(hiredate date) returns integer
    language plpgsql
as
$$
declare
    rec record;
begin
     select expo_id
        from expo_2017  into strict rec
            where hire_date =hireDate;
                return  rec.expo_id;
        exception
        when no_data_found then
            raise exception 'Not 2 found';
        when sqlstate 'P0002'then
            raise exception 'Not found';
        when sqlstate 'P0003' then
            raise exception 'Not unique';

end
$$;

alter function pr1(date) owner to postgres;

