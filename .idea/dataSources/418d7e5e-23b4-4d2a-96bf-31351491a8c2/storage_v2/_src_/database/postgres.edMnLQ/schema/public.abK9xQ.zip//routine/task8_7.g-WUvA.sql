create function task8_7(refcursor) returns SETOF refcursor
    language plpgsql
as
$$
begin
        OPEN $1  for select  d.department_name, d.manager_id, d.locations_id, e.first_name,e.last_name,e.department_id
                    from department d
                    inner join employee e on d.department_id = e.department_id
                    where department_name like 'S%';
        RETURN NEXT $1;
    end
$$;

alter function task8_7(refcursor) owner to postgres;

