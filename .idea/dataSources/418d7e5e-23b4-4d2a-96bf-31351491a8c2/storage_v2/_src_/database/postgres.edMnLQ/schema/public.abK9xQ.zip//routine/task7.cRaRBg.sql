create function task7()
    returns TABLE(return_name character varying)
    language plpgsql
as
$$
declare
    name employee.first_name%type;
begin
    for name in select first_name
        from employee
        where first_name  like 'A%' or first_name  like 'B%'
        or first_name  like  'C%' or first_name  like  'D%' or first_name  like  'E%'
        or first_name  like  'F%' or first_name  like  'G%' or first_name  like  'H%'
        or first_name  like  'I%' or first_name  like  'J%' or first_name  like  'K%'
        or first_name  like  'L%' or first_name  like  'M%' or first_name  like  'N%'
        or first_name  like  'O%'
        loop
        Return_name:=name;
		return next;
		end loop;
end
$$;

alter function task7() owner to postgres;

