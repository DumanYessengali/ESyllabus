create function p_trigger() returns trigger
    language plpgsql
as
$$
begin
   insert into p_audit(p_id, p_name, expo_id)
   values (new.p_id, new.p_name, new.expo_id);
   return new;
end
$$;

alter function p_trigger() owner to postgres;

