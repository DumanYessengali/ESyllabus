create function task5()
    returns TABLE(long_name_return character varying, return_char_length integer)
    language plpgsql
as
$$
declare
    LongName employee.first_name%type;
    char_length int;
begin
    for LongName,char_length in select concat(first_name,' ',last_name) as full_name,  max(char_length(concat(first_name,' ',last_name))) as char_length
        from employee
        where char_length(concat(first_name,' ',last_name)) IN (select max(char_length(concat(first_name,' ',last_name))) from employee)
        group by full_name
        loop
            Long_Name_Return:=LongName;
            Return_char_length:=char_length;
		return next;
		end loop;
end
$$;

alter function task5() owner to postgres;

