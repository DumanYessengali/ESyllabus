create function task3()
    returns TABLE(returndep character varying, mindate date)
    language plpgsql
as
$$
declare
    deppartmenName department.department_name%type;
    minDay date;
begin
    for deppartmenName, minDay in select  d.department_name ,max(hire_date) as maxDate
        from employee
            inner join department d on employee.department_id = d.department_id
            where employee.hire_date IN (select max(hire_date) from employee)
            group by d.department_name
        loop
            ReturnDep:=deppartmenName;
            Mindate:=minDay;
		return next;
		end loop;
end
$$;

alter function task3() owner to postgres;

