create function task7_1(insethiredate date) returns character varying
    language plpgsql
as
$$
declare
    rec record;
begin
    select  hire_date
    into strict rec
    from employee
    where hire_date like concat('%',InsetHireDate);
    exception
        when sqlstate 'P0002' then
			raise exception '% not found', rec.hire_date;
		when sqlstate 'P0003' then
			raise exception '% found', rec.hire_date;
end
$$;

alter function task7_1(date) owner to postgres;

