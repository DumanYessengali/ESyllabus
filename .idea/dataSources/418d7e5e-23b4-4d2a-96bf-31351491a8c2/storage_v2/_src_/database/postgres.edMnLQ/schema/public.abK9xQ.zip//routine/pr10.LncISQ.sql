create procedure pr10(tid integer)
    language plpgsql
as
$$
begin
   delete from ticket
   where ticket_id = tID;
   commit;
end
$$;

alter procedure pr10(integer) owner to postgres;

