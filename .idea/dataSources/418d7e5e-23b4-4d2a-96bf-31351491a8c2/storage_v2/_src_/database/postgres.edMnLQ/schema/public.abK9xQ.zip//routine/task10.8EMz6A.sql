create function task10(domen character varying)
    returns TABLE(report_email character varying)
    language plpgsql
as
$$
declare
   email employee.email%type;
begin
    for email in select employee.email
        from employee
        where employee.email like concat('%',domen)
        loop
           Report_Email:=email;
		return next;
		end loop;
end
$$;

alter function task10(varchar) owner to postgres;

