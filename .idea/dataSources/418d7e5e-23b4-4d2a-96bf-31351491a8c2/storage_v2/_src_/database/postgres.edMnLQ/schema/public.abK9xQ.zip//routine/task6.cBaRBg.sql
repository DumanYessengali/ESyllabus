create function task6()
    returns TABLE(return_full_name character varying, return_day integer, return_dep character varying)
    language plpgsql
as
$$
declare
    full_name employee.first_name%type;
    day int;
    dep department.department_name%type;
begin
    for full_name,day,dep in select concat(first_name,' ',last_name) as full_name, extract(days from (now() - hire_date)) , d.department_name
        from employee
        inner join department d on employee.department_id = d.department_id
        group by full_name,d.department_name,hire_date
        loop
            Return_full_name:=full_name;
            Return_day:=day;
            Return_dep:=dep;
		return next;
		end loop;
end
$$;

alter function task6() owner to postgres;

