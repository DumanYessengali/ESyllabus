create function task1(startp integer, endp integer)
    returns TABLE(full_name character varying, id integer)
    language plpgsql
as
$$
declare
    full_nameE varchar;
    idE employee.employee_id%type;
begin
    for full_nameE,idE in select concat(first_name,' ',last_name),employee_id
        from employee
            where employee_id between startP and endP
        loop
            full_name:=full_nameE;
            id:=idE;
		return next;
		end loop;
end;
$$;

alter function task1(integer, integer) owner to postgres;

