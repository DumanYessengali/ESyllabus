create view num_of_empl_in_each_(first_name, last_name, number_of_employees) as
SELECT sup.first_name,
       sup.last_name,
       count(sub.employee_id) AS number_of_employees
FROM employee sub
         JOIN employee sup ON sub.manager_id = sup.employee_id
GROUP BY sup.employee_id, sup.first_name, sup.last_name;

alter table num_of_empl_in_each_
    owner to postgres;

