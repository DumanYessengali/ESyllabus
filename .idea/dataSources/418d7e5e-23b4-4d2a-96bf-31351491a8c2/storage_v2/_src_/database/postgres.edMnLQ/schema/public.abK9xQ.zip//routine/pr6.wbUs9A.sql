create function pr6(datee date) returns character varying
    language plpgsql
as
$$
declare
        newText varchar(255) default '';
        rec record;
        cur cursor(datee date)
            for select  descr, Sale_channels, Cost, date
            from ticket
            where ticket.date=datee;
    begin
        open cur(datee);
        loop
            fetch cur into rec;
            exit when not FOUND;

            newText:=rec.descr||' '||rec.Sale_channels||' '||rec.Cost||' '||rec.date;
        end loop;
        close cur;
        return newText;
        exception
            when no_data_found then
                raise exception 'Not found';
            when sqlstate 'P0002'then
                raise exception 'Not found';
            when sqlstate 'P0003' then
                raise exception 'Not unique';
    end
$$;

alter function pr6(date) owner to postgres;

