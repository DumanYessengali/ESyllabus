create procedure task7_3()
    language plpgsql
as
$$
declare
	rec record;
begin
    for rec in select last_name,gender
        from employee
            where gender='Male' and last_name like 'B%'
    loop
		raise notice '% % ', rec.last_name, rec.gender;
	 end loop;
	commit;
end;
$$;

alter procedure task7_3() owner to postgres;

