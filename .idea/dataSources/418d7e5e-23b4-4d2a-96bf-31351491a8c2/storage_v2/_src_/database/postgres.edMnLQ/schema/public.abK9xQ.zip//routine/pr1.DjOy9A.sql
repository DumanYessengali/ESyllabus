create function pr1(startp integer, endp integer) returns text
    language plpgsql
as
$$
declare
    NameE varchar;
    addressE expo_2017.address%type;
begin
    select EXPO_2017.name,expo_2017.address
        from expo_2017 into strict NameE,addressE
            where expo_id between startP and endP;
            return NameE||' '||addressE;
               exception
                when no_data_found then
                    raise exception 'Not found';
                when sqlstate 'P0002'then
                    raise exception 'Not found';
                when sqlstate 'P0003' then
                    raise exception 'Not unique';
end;
$$;

alter function pr1(integer, integer) owner to postgres;

