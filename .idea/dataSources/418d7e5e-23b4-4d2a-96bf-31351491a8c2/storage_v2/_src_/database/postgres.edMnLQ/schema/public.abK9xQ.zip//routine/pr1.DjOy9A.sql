create function pr1(startp integer, endp integer)
    returns TABLE(name character varying, address character varying)
    language plpgsql
as
$$
declare
    NameE varchar;
    addressE expo_2017.address%type;
begin
    for NameE,addressE in select EXPO_2017.name,expo_2017.address
        from expo_2017
            where expo_id between startP and endP
        loop
            Name:=NameE;
            address:=addressE;
      return next;
      end loop;
end;
$$;

alter function pr1(integer, integer) owner to postgres;

