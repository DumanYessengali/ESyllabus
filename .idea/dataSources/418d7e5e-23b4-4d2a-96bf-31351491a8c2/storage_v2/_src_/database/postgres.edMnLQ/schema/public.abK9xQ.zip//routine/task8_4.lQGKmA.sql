create function task8_4(datee date) returns text
    language plpgsql
as
$$
declare
        newText text default '';
        rec record;
        cur cursor(datee date)
            for select first_name,last_name,hire_date,email
            from employee
            where hire_date=datee;
        newText1 text default '';
    begin
        open cur(datee);
        loop
            fetch cur into rec;
            exit when not FOUND;

            if concat(rec.first_name,' ',rec.last_name) like 'A%' then
                newText:=concat(rec.first_name,' ',rec.last_name)||' '||rec.hire_date||' '||rec.email;
            end if;
        end loop;
        close cur;
        return newText;
    end
$$;

alter function task8_4(date) owner to postgres;

