create function task4()
    returns TABLE(returndep character varying, sumdep integer)
    language plpgsql
as
$$
declare
    deppartmenName department.department_name%type;
    SumDepR int;
begin
    for deppartmenName, SumDepR in select  d.department_name ,avg(employee.salary)
        from employee
            inner join department d on employee.department_id = d.department_id
            group by d.department_name
        loop
            ReturnDep:=deppartmenName;
            SumDep:=SumDepR;
      return next;
      end loop;
end
$$;

alter function task4() owner to postgres;

